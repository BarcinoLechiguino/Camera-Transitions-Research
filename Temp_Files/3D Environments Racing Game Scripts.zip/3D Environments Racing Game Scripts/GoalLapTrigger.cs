﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalLapTrigger : MonoBehaviour
{
    public GameObject victory_zone;                                                     // The floor of the victory_zone. Will be used as the point where the player will be teleported on finishing the race.
    public GameObject checkPoint;                                                       // The checkpoint that will need to be reached in order to make it a new lap (See is_new_lap).
    public GameObject lap_counter;                                                      // Empty GameObject that will be used as the position where the cubes that will represent the completed laps will appear.
    public GameObject win_cube;                                                         // The GameObject without rigid body that will be instantiated to represent the completed laps. Can be a cube, a sphere...

    public int  target_laps = 3;                                                        // The total amount of laps that the player will need to do in order to finish the race.
    public int  current_laps = 0;                                                       // The current amount of laps that the player has completed so far.
    public bool race_has_finished = false;                                              // Will be set to true when the race has finished (All laps have been completed).
    public bool is_new_lap = true;                                                      // Will keep track whether or not the trigger at the goal must increase current_laps or not. Will increase laps if true. 

    private void OnTriggerEnter(Collider player)
    {
        if (is_new_lap)
        {
            current_laps++;
            is_new_lap = false;

            SpawnLapCounter(current_laps);
        }

        CheckWinCondition(player);
    }

    public void SpawnLapCounter(int lap)                                                // Spawns a GameObject to represent that a lap has been completed.
    {
        GameObject cube = Instantiate(win_cube) as GameObject;                          // Creates a copy of a game  element in the enviroment.

        Vector3 vec = new Vector3(cube.transform.localScale.x * 2, 0, 0);               // Vector used to distance the lap cubes.

        if (lap == 1)
        {
            cube.transform.position = lap_counter.transform.position;                   // Sets the instantiated cube's position to the position of the lap_counter.
        }
        if (lap == 2)
        {
            cube.transform.position = lap_counter.transform.position + vec;
        }
        if (lap == 3)
        {
            cube.transform.position = lap_counter.transform.position + vec * 2;
        }
    }

    public void CheckWinCondition(Collider player)                                      // Checks if all laps have been completed. If all laps have been completed the player is sent to the victory zone. 
    {
        if (current_laps == target_laps)
        {
            race_has_finished = true;
        }

        if (race_has_finished)
        {
            player.gameObject.transform.position = victory_zone.transform.position;     // When all laps have been completed, the player is sent to the victory zone.
        }
    }
}
