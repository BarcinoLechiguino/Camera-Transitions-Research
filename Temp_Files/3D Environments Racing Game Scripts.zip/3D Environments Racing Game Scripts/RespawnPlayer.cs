﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnPlayer : MonoBehaviour
{
    //public GameObject[] respawn_point;                                                // To make different respawn points an array of GameObjects or position to respawn to are needed.
                                                                                       // There needs to be something (bool or distance with player) that can identify which respawn point to use.
    
    public GameObject respawn_point;

    private void OnTriggerEnter(Collider player)
    {
        // Something like this or similar to handle multiple respawn points.
        /*int size = respawn_point.Length;

        for (int i = 0; i < size; i++)
        {
            if (respawn_point[i].transform.position.x - player.transform.position.x < 50)
            {
                player.gameObject.transform.position = respawn_point[i].transform.position;        // Respawns the player back at the respawn point.
                break;
            }
        }*/

        player.gameObject.transform.position = respawn_point.transform.position;        // Respawns the player back at the respawn point.
    }
}
