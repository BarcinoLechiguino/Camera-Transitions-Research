﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointReached : MonoBehaviour
{
    public Collider         checkpoint_collider;
    public GoalLapTrigger   goal_trigger;

    private void OnTriggerEnter(Collider player)
    {
        goal_trigger.is_new_lap = true;                     // If the player has reached this checkpoint, the lap is considered a new one (so it can count when a lap is completed).
    }
}
