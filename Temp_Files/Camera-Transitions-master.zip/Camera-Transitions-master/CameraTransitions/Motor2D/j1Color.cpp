#include "j1Color.h"

j1Color Black = j1Color(0.0f, 0.0f, 0.0f);
j1Color Grey = j1Color(10.0f, 10.0f, 10.0f);
j1Color White = j1Color(255.0f, 255.0f, 255.0f);
j1Color Red = j1Color(255.0f, 0.0f, 0.0f);
j1Color Green = j1Color(0.0f, 255.0f, 0.0f);
j1Color Blue = j1Color(0.0f, 0.0f, 255.0f);