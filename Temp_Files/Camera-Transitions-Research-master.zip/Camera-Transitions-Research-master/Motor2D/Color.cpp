#include "Color.h"

Color Red = Color(255.0F, 0.0F, 0.0F);
Color Green = Color(0.0F, 255.0F, 0.0F);
Color Blue = Color(0.0F, 0.0F, 255.0F);
Color Black = Color(0.0F, 0.0F, 0.0F);
Color White = Color(255.0F, 255.0F, 255.0F);
Color Cian = Color(0.0F, 255.0F, 255.0F);
Color Yellow = Color(255.0F, 255.0F, 0.0F);
Color Pink = Color(255.0F, 155.0F, 255.0F);
Color DarkGray = Color(75.0F, 75.0F, 100.0F);